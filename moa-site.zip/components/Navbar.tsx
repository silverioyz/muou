import Link from 'next/link';

const Navbar = () => {
  return (
    <nav className="bg-green-800 text-white px-6 py-4 shadow-lg sticky top-0 z-50 backdrop-blur-sm">
      <ul className="flex flex-wrap justify-center gap-8 text-lg font-semibold">
        <li><Link href="/">Início</Link></li>
        <li><Link href="/solucoes">Nossas Soluções</Link></li>
        <li><Link href="/cooperativas">Cooperativas</Link></li>
        <li><Link href="/sobre">Quem Somos</Link></li>
        <li><Link href="/blog">Blog</Link></li>
        <li><Link href="/contato">Fale com um Especialista</Link></li>
        <li><Link href="/login">Área do Cliente</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;
