import React from 'react';

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-center p-12">
      <section className="mb-16">
        <h1 className="text-5xl font-bold text-green-800">Somos especialistas na Contabilidade do Agronegócio.</h1>
        <p className="text-xl text-gray-700 mt-4">Somos <span className="text-green-900 font-semibold">MOA</span></p>
        <a href="/solucoes" className="inline-block mt-6 px-6 py-3 bg-green-700 text-white rounded-lg text-lg hover:bg-green-800 transition">CONHEÇA NOSSAS SOLUÇÕES →</a>
      </section>

      <section className="flex flex-wrap justify-center gap-12 text-green-900 text-xl font-semibold">
        <div>
          <p className="text-6xl font-bold">25</p>
          <p>ANOS DE MERCADO</p>
        </div>
        <div>
          <p className="text-6xl font-bold">+300</p>
          <p>COLABORADORES</p>
        </div>
        <div>
          <p className="text-6xl font-bold">+700</p>
          <p>CLIENTES EM TODO O PAÍS</p>
        </div>
      </section>
    </main>
  );
}
