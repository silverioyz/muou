import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function AreaCliente() {
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('logado') !== 'true') {
      router.push('/login');
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('logado');
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-green-50 p-10 text-green-900 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold mb-4">Bem-vindo à Área do Cliente</h1>
        <button
          onClick={handleLogout}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          Sair
        </button>
      </div>
      <p>Aqui você poderá acessar seus documentos, visualizar relatórios e conversar com nossos especialistas.</p>
    </div>
  );
}
