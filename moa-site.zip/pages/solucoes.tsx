import React from 'react';

export default function Solucoes() {
  return (
    <div className="min-h-screen p-10 bg-white">
      <h1 className="text-4xl font-bold text-green-900 mb-6">Nossas Soluções</h1>
      <p className="text-green-700 max-w-3xl text-lg leading-relaxed">
        Oferecemos soluções contábeis personalizadas para o setor agro, desde planejamento tributário até gestão financeira e auditorias completas. Nosso objetivo é impulsionar sua produtividade com segurança e inteligência.
      </p>
    </div>
  );
}
