import React from 'react';

const Cooperativas = () => {
  return (
    <div className="min-h-screen p-10 bg-green-50">
      <h1 className="text-4xl font-bold text-green-900 mb-6">Cooperativas Parceiras</h1>
      <p className="text-green-700 max-w-3xl text-lg leading-relaxed">
        A MOA trabalha em conjunto com diversas cooperativas agrícolas espalhadas pelo país, promovendo desenvolvimento sustentável e maior alcance de mercado para os produtores rurais.
      </p>
      <ul className="mt-6 space-y-3 text-green-800 list-disc list-inside">
        <li>Cooperativa Agro Sul</li>
        <li>Cooperverde</li>
        <li>UniAgro Coop</li>
        <li>Cooperfaz</li>
      </ul>
    </div>
  );
};

export default Cooperativas;
