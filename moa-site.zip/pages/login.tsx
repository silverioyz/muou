import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('logado') === 'true') {
      router.push('/area-cliente');
    }
  }, [router]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();

    if (email === 'cliente@moa.com' && senha === '123456') {
      localStorage.setItem('logado', 'true');
      router.push('/area-cliente');
    } else {
      setErro('E-mail ou senha inválidos');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-green-100 p-4">
      <form onSubmit={handleLogin} className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md space-y-6 animate-fade-in">
        <h2 className="text-2xl font-bold text-green-800 text-center">Área do Cliente</h2>
        {erro && <p className="text-red-600 text-sm text-center">{erro}</p>}
        <input
          type="email"
          placeholder="Seu e-mail"
          className="w-full px-4 py-2 border border-green-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Sua senha"
          className="w-full px-4 py-2 border border-green-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          required
        />
        <button
          type="submit"
          className="w-full bg-green-700 text-white py-2 rounded-lg hover:bg-green-800 transition"
        >
          Entrar
        </button>
      </form>
    </div>
  );
}
