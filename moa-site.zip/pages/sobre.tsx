import React from 'react';

export default function Sobre() {
  return (
    <div className="min-h-screen p-10 bg-green-100">
      <h1 className="text-4xl font-bold text-green-900 mb-6">Quem Somos</h1>
      <p className="text-green-800 max-w-3xl text-lg leading-relaxed">
        A MOA é uma empresa especializada em contabilidade para o agronegócio, com mais de 25 anos de mercado, mais de 300 colaboradores e atuação em todo o país. Somos comprometidos com a excelência, inovação e o desenvolvimento sustentável do setor agro.
      </p>
    </div>
  );
}
